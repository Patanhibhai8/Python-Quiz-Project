from tkinter import *
from pygame import mixer

mixer.init()
mixer.music.load('naruto2.mp3')
mixer.music.play(-1)

questions = ["At what age itachi became leader of anbu black ops?",
             "Who is Madara's eternal rival?",
             "Who gave sasuke a rinnegan?",
             "What is kakashi's nickname?",
             "What is highest ranking of Naruto?",
             "Who was the fourth hokage of village hidden in the leaf",
             "Who was the most powerful member of Hyuga clan?",
             "In which type of jutsu rock lee is strongest of all?",
             "Who was the real pain?",
             "What name nartuo used to call jiraiya?"]

first_option = ["12", "Tobirama",
                "Itachi", "Knucklehead",
                "Hokage", "Hiruzen",
                "Hinata", "Ninjutsu", "Obito", "Pervy sage"]

second_option = ["15", "Minato",
                 "Orochimaru", "Copy Ninja",
                 "Chunin", "Orochimaru",
                 "Neji", "Genjutsu", "Yahiko", "Master"]

third_option = ["16", "Hashirama",
                "Madara", "Yellow Flash",
                "Jonin", "Jiraiya",
                "Hanabi", "Taijutsu", "Konan", "Sensei"]

fourth_option = ["20", "Naruto",
                 "Hagoromo", "White Fang",
                 "Genin", "Minato",
                 "Hiashi", "Sagejutsu", "Nagato", "Sanin"]

correct_answers = ["12", "Hashirama", "Hagoromo", "Copy Ninja", "Hokage", "Minato",
                   "Neji", "Taijutsu", "Nagato", "Pervy sage"]

def select(event):
    mixer.music.set_volume(1)
    b = event.widget
    value = b['text']

    for i in range(10):
        if value == correct_answers[i]:
            if value == correct_answers[9]:
                def playagain():
                    characterlabel.config(image=characterimage)
                    questionArea.delete(1.0, END)
                    questionArea.insert(END, questions[0])
                    optionButton1.config(text=first_option[0])
                    optionButton2.config(text=second_option[0])
                    optionButton3.config(text=third_option[0])
                    optionButton4.config(text=fourth_option[0])
                    root2.destroy()
                    mixer.music.load('naruto2.mp3')
                    mixer.music.play(-1)

                def on_closing():
                    root2.destroy()
                    root.destroy()

                characterlabel.config(image=image9)
                mixer.music.stop()
                mixer.music.load('naruto1.mp3')
                mixer.music.play()
                root2 = Toplevel()
                root2.overrideredirect(True)
                root2.grab_set()
                root2.config(bg='black')
                root2.geometry('500x400+140+30')
                root2.title('SHARINGAN QUIZ - YOU WON')
                logoimage = PhotoImage(file='sharinganlogo.png')
                logolabel = Label(root2, image=logoimage, bd=0, bg='black')
                logolabel.pack(pady=30)

                winlabel = Label(root2, text='You Won, you are a true naruto fan', font=('arial', 20, 'bold'), bg='black', fg='white')
                winlabel.pack()

                rinneganimage = PhotoImage(file='rinnegan.png')
                rinneganLabel = Label(root2, image=rinneganimage, bg='black')
                rinneganLabel.place(x=400, y=280)

                happYLabel1 = Label(root2, image=rinneganimage, bg='black')
                happYLabel1.place(x=30, y=280)

                playagainButton = Button(root2, text='Play Again', font=('arial', 20, 'bold'), bg='black', fg='white',
                                         bd=0
                                         , activebackground='black', cursor='hand2', activeforeground='white',
                                         command=playagain)
                playagainButton.pack()

                closeButton = Button(root2, text='Close', font=('arial', 20, 'bold'), bg='black', fg='white', bd=0
                                     , activebackground='black', cursor='hand2', activeforeground='white',
                                     command=on_closing)
                closeButton.pack()

                root2.protocol('WM_DELETE_WINDOW', on_closing)
                root2.mainloop()
                break

            questionArea.delete(1.0, END)
            questionArea.insert(END, questions[i + 1])

            optionButton1.config(text=first_option[i + 1])
            optionButton2.config(text=second_option[i + 1])
            optionButton3.config(text=third_option[i + 1])
            optionButton4.config(text=fourth_option[i + 1])
            characterlabel.config(image=images[i])

        if value not in correct_answers:
            def tryagain():
                mixer.music.load('naruto2.mp3')
                mixer.music.play(-1)

                questionArea.delete(1.0, END)
                questionArea.insert(END, questions[0])
                optionButton1.config(text=first_option[0])
                optionButton2.config(text=second_option[0])
                optionButton3.config(text=third_option[0])
                optionButton4.config(text=fourth_option[0])
                characterlabel.config(image=characterimage)
                root1.destroy()

            def on_closing():
                root1.destroy()
                root.destroy()

            mixer.music.stop()
            root1 = Toplevel()
            root1.overrideredirect(True)
            root1.grab_set()
            root1.config(bg='black')
            root1.geometry('500x400+140+30')
            root1.title('SHARINGAN QUIZ - YOU LOSE')
            img = PhotoImage(file='sharinganlogo.png')
            logoLabel = Label(root1, image=img, bd=0, bg='black')
            logoLabel.pack(pady=30)
            loselabel = Label(root1, text='You Lose, you are not a true naruto fan', font=('arial', 18, 'bold'), bg='black', fg='white')
            loselabel.pack()
            mangekyouimage = PhotoImage(file='mangekyou.png')
            mangekyoulabel = Label(root1, image=mangekyouimage, bg='black')
            mangekyoulabel.place(x=400, y=280)
            mangekyoulabel1 = Label(root1, image=mangekyouimage, bg='black')
            mangekyoulabel1.place(x=30, y=280)

            tryagainButton = Button(root1, text='Try Again', font=('arial', 20, 'bold'), bg='black', fg='white', bd=0
                                    , activebackground='black', cursor='hand2', activeforeground='white',
                                    command=tryagain)
            tryagainButton.pack()

            closeButton = Button(root1, text='Close', font=('arial', 20, 'bold'), bg='black', fg='white', bd=0
                                 , activebackground='black', cursor='hand2', activeforeground='white',
                                 command=on_closing)
            closeButton.pack()

            root1.mainloop()

            break



root = Tk()
root.geometry('1270x652+0+0')
root.resizable(0, 0)
root.title("SHARINGAN QUIZ - LET'S SEE WHO IS TRUE NARUTO FAN")
root.config(bg='black')

leftFrame = Frame(root, bg='black', padx=90)
leftFrame.grid(row=0, column=0)

rightFrame = Frame(root, bg='black', padx=50, pady=25)
rightFrame.grid(row=0, column=1)

topframe = Frame(leftFrame, bg='black', pady=15)
topframe.grid(row=1, column=0)

bottomFrame = Frame(leftFrame, bg='black')
bottomFrame.grid(row=2, column=0)

logoimage = PhotoImage(file='sharinganlogo.png')
logoLabel = Label(topframe, image=logoimage, bd=0, width=300, height=200, bg='black')
logoLabel.grid(row=0, column=0)

characterimage = PhotoImage(file='itachi.png')
image1 = PhotoImage(file='madara.png')
image2 = PhotoImage(file='sasuke.png')
image3 = PhotoImage(file='kakashi.png')
image4 = PhotoImage(file='naruto.png')
image5 = PhotoImage(file='minato.png')
image6 = PhotoImage(file='neji.png')
image7 = PhotoImage(file='rock_lee.png')
image8 = PhotoImage(file='pain.png')
image9 = PhotoImage(file='pervysage.png')

images = [image1, image2, image3, image4, image5, image6, image7, image8, image9]

characterlabel = Label(rightFrame, image=characterimage, bg='black', bd=0)
characterlabel.grid(row=0, column=0)

layoutimage = PhotoImage(file='lay.png')
layoutlabel = Label(bottomFrame, image=layoutimage, bg='black', bd=0)
layoutlabel.grid(row=0, column=0)

questionArea = Text(bottomFrame, font=('arial', 18, 'bold'), bg='black', fg='white', width=34, height=2,
                        wrap='word',bd=0)
questionArea.place(x=70,y=10)

questionArea.insert(END, questions[0])

labelA = Label(bottomFrame, font=('arial', 16, 'bold'), text='A:', bg='black', fg='white')
labelA.place(x=60,y=110)

optionButton1 = Button(bottomFrame, text=first_option[0], font=('arial', 18, 'bold'), bg='black', fg='white',
                              cursor='hand2',bd=0,activebackground='black',activeforeground='white')
optionButton1.place(x=100,y=100)

labelB = Label(bottomFrame, font=('arial', 16, 'bold'), text='B:', bg='black', fg='white')
labelB.place(x=330,y=110)

optionButton2 = Button(bottomFrame, text=second_option[0], font=('arial', 18, 'bold'), bg='black', fg='white',
                              cursor='hand2',bd=0,activebackground='black',activeforeground='white')
optionButton2.place(x=370,y=100)

labelC = Label(bottomFrame, font=('arial', 16, 'bold'), text='C:', bg='black', fg='white')
labelC.place(x=60,y=190)

optionButton3 = Button(bottomFrame, text=third_option[0], font=('arial', 18, 'bold'), bg='black', fg='white',
                             cursor='hand2',bd=0,activebackground='black',activeforeground='white')
optionButton3.place(x=100,y=180)

labelD = Label(bottomFrame, font=('arial', 16, 'bold'), text='D:', bg='black', fg='white')
labelD.place(x=330,y=190)

optionButton4 = Button(bottomFrame, text=fourth_option[0], font=('arial', 18, 'bold'), bg='black', fg='white',
                             cursor='hand2',bd=0,activebackground='black',activeforeground='white')
optionButton4.place(x=370,y=180)

optionButton1.bind('<Button-1>', select)
optionButton2.bind('<Button-1>', select)
optionButton3.bind('<Button-1>', select)
optionButton4.bind('<Button-1>', select)

root.mainloop()
